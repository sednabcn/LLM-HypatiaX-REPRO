#!/usr/bin/env bash
#
# anonymize-repo.sh
#
# Rewrites a git repository's history so every commit's author/committer
# identity is replaced with an anonymous placeholder, and (optionally)
# scrubs literal identity strings (name/email/aliases) out of commit
# messages and tracked file contents.
#
# Requires: git-filter-repo (https://github.com/newren/newren/git-filter-repo)
#   Install: pip install git-filter-repo --break-system-packages
#            (or: brew install git-filter-repo / apt install git-filter-repo)
#
# USAGE
#   ./anonymize-repo.sh /path/to/repo [options]
#
# OPTIONS
#   --name "Anonymous"              New name for every commit (default: Anonymous)
#   --email "anon@example.com"      New email for every commit (default: anon@example.com)
#   --redact-file FILE              Optional text file with strings to scrub, one per line
#                                    (real name, email, aliases, company name, etc.)
#                                    Each line is replaced with "[REDACTED]" wherever it
#                                    appears in commit messages and file contents.
#   --dry-run                       Do everything on a throwaway copy of the repo and
#                                    report what would change, without touching the original.
#   --no-remote-strip               Keep the existing 'origin' remote (default: it is removed
#                                    after rewrite, since pushing rewritten history to the old
#                                    remote requires --force and a decision only you should make).
#   --fresh-history                 Nuclear option. Instead of rewriting every old commit,
#                                    discard history entirely: collapse the current working
#                                    tree into ONE new commit with the anonymous identity, on
#                                    an otherwise-empty branch. All other local branches and
#                                    tags are deleted (they'd still contain the old history),
#                                    old objects are pruned so they aren't just hidden in a
#                                    reflog, and --redact-file is applied to the on-disk files
#                                    before that single commit is made. Simpler and harder to
#                                    get wrong than history rewriting, but you lose all commit
#                                    history, not just identity — only the current snapshot survives.
#   --fresh-branch NAME             Branch name for the fresh commit (default: current branch name).
#   --fresh-message MSG             Commit message for the fresh commit (default: "Initial commit").
#   -h, --help                      Show this help.
#
# WHAT THIS DOES
#   Default mode (history rewrite):
#     1. Rewrites every commit's author name/email and committer name/email.
#     2. Optionally scrubs literal strings (from --redact-file) out of commit
#        messages and all tracked file content, at every point in history.
#     3. Runs a verification grep over the rewritten history for the strings
#        you asked to redact, and prints anything still found.
#   --fresh-history mode:
#     1. Scrubs literal strings (from --redact-file) out of the current on-disk
#        tracked files (no history to worry about, only today's snapshot).
#     2. Collapses everything into a single new commit under the anonymous
#        identity, on a fresh orphan branch; deletes all other local branches/tags.
#     3. Expires the reflog and runs `git gc --prune=now` so the old commits
#        are actually removed from the local object store, not just unreferenced.
#   Both modes then:
#     4. Removes the 'origin' remote (unless --no-remote-strip) so you can't
#        accidentally push rewritten history over the real remote by habit.
#     5. Leave you a checklist of things this script CANNOT fix (see below).
#
# WHAT THIS SCRIPT CANNOT FIX (do these yourself)
#   - GPG signatures on old commits will become invalid (identity changed) —
#     the script drops signatures; re-sign if you need signed history.
#   - Any copy of the repo already pushed/cloned elsewhere (GitHub forks,
#     CI caches, teammates' clones) still has the old history. You must
#     force-push AND ask collaborators to re-clone, and old commits may
#     survive in the host's server-side reflogs/PR history/Actions logs
#     until the host purges them (GitHub, GitLab etc. all differ here).
#   - Identity leaked outside git content: issue trackers, PR descriptions,
#     commit-signing keys registered to your account, SSH/HTTPS auth used
#     to push, CI secrets, README/LICENSE "Copyright <name>" lines that
#     aren't in your redact list, etc.
#   - IP addresses, timestamps, or timezone offsets that could fingerprint
#     you (times are preserved as-is by default).
#
set -euo pipefail

usage() { sed -n '2,60p' "$0" | sed 's/^#\s\?//'; exit 1; }

REPO=""
NEW_NAME="Anonymous"
NEW_EMAIL="anon@example.com"
REDACT_FILE=""
DRY_RUN=0
STRIP_REMOTE=1
FRESH_HISTORY=0
FRESH_BRANCH=""
FRESH_MESSAGE="Initial commit"

while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help) usage ;;
    --name) NEW_NAME="$2"; shift 2 ;;
    --email) NEW_EMAIL="$2"; shift 2 ;;
    --redact-file) REDACT_FILE="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    --no-remote-strip) STRIP_REMOTE=0; shift ;;
    --fresh-history) FRESH_HISTORY=1; shift ;;
    --fresh-branch) FRESH_BRANCH="$2"; shift 2 ;;
    --fresh-message) FRESH_MESSAGE="$2"; shift 2 ;;
    *)
      if [ -z "$REPO" ]; then REPO="$1"; shift; else
        echo "Unknown argument: $1" >&2; usage
      fi
      ;;
  esac
done

[ -n "$REPO" ] || { echo "Error: repo path required." >&2; usage; }
[ -d "$REPO/.git" ] || { echo "Error: '$REPO' is not a git repository (no .git dir)." >&2; exit 1; }

if [ "$FRESH_HISTORY" -eq 0 ] && ! command -v git-filter-repo >/dev/null 2>&1; then
  echo "Error: git-filter-repo is not installed." >&2
  echo "Install with: pip install git-filter-repo --break-system-packages" >&2
  exit 1
fi

REPO="$(cd "$REPO" && pwd)"
WORK_REPO="$REPO"

if [ "$DRY_RUN" -eq 1 ]; then
  WORK_REPO="$(mktemp -d)/repo-dryrun"
  echo "[dry-run] Cloning '$REPO' to throwaway copy: $WORK_REPO"
  git clone --no-local --mirror "$REPO" "$WORK_REPO.git" >/dev/null 2>&1 || {
    # --no-local mirror needs a proper clone; fall back to a plain local clone
    rm -rf "$WORK_REPO.git"
    git clone "$REPO" "$WORK_REPO" >/dev/null
  }
  if [ -d "$WORK_REPO.git" ]; then
    git clone "$WORK_REPO.git" "$WORK_REPO" >/dev/null
  fi
fi

echo "== Anonymizing: $WORK_REPO =="
echo "New identity for all commits: $NEW_NAME <$NEW_EMAIL>"

cd "$WORK_REPO"

if [ "$REDACT_FILE" != "" ] && [ ! -f "$REDACT_FILE" ]; then
  echo "Error: redact file '$REDACT_FILE' not found." >&2
  exit 1
fi

if [ "$FRESH_HISTORY" -eq 1 ]; then
  # --- Fresh-history mode: collapse to a single anonymous commit ---
  ORIG_BRANCH="$(git symbolic-ref --short -q HEAD || echo main)"
  TARGET_BRANCH="${FRESH_BRANCH:-$ORIG_BRANCH}"
  TMP_BRANCH="__anonymize_fresh_$$"

  echo "== Fresh-history mode: collapsing to one commit on branch '$TARGET_BRANCH' =="

  # Step 1: redact on-disk tracked file contents (no history left to worry about)
  if [ -n "$REDACT_FILE" ]; then
    echo "== Redacting strings listed in: $REDACT_FILE (working tree only) =="
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      # NUL-delimited to survive filenames with spaces/newlines
      git ls-files -z | while IFS= read -r -d '' f; do
        [ -f "$f" ] || continue
        # Skip binary files; grep -Iq returns non-zero for them
        if grep -Iq . "$f" 2>/dev/null && grep -qF -- "$line" "$f" 2>/dev/null; then
          # Use perl for reliable literal find/replace. The redact string is passed
          # via env var (not interpolated into the program text) because \Q..\E only
          # escapes regex metacharacters, not Perl's OWN string interpolation — an
          # '@' or '$' in the literal (e.g. an email address) would otherwise be
          # misread as an array/scalar interpolation and silently mangled.
          REDACT_LINE="$line" perl -i -pe 's/\Q$ENV{REDACT_LINE}\E/[REDACTED]/g' "$f"
        fi
      done
    done < "$REDACT_FILE"
  fi

  # Step 2: build the orphan branch with everything currently tracked
  git checkout --orphan "$TMP_BRANCH" >/dev/null
  git add -A
  GIT_AUTHOR_NAME="$NEW_NAME" GIT_AUTHOR_EMAIL="$NEW_EMAIL" \
  GIT_COMMITTER_NAME="$NEW_NAME" GIT_COMMITTER_EMAIL="$NEW_EMAIL" \
    git commit -q -m "$FRESH_MESSAGE"

  # Step 3: delete every other branch and tag (they still hold old history)
  for b in $(git for-each-ref --format='%(refname:short)' refs/heads/); do
    [ "$b" = "$TMP_BRANCH" ] && continue
    git branch -D "$b" >/dev/null 2>&1 || true
  done
  for t in $(git tag -l); do
    git tag -d "$t" >/dev/null 2>&1 || true
  done
  # Also drop remote-tracking refs (refs/remotes/origin/*, origin/HEAD, etc).
  # These aren't branches or tags but still keep old commits reachable, which
  # would both inflate the verification count below and stop them being pruned.
  for r in $(git for-each-ref --format='%(refname)' refs/remotes/); do
    git update-ref -d "$r" >/dev/null 2>&1 || true
  done
  git branch -M "$TMP_BRANCH" "$TARGET_BRANCH"

  # Step 4: actually purge old objects, not just unreference them
  echo "== Pruning old history from the local object store =="
  git reflog expire --expire=now --all >/dev/null 2>&1 || true
  git gc --prune=now --aggressive -q

  # Step 5: verification pass
  echo "== Verifying: scanning for leftover identity strings and old commits =="
  FOUND=0
  if [ -n "$REDACT_FILE" ]; then
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      if git log --all -p | grep -qF -- "$line"; then
        echo "  !! Still found: $line"
        FOUND=1
      fi
    done < "$REDACT_FILE"
  fi
  COMMIT_COUNT="$(git rev-list --all --count)"
  if [ "$COMMIT_COUNT" -ne 1 ]; then
    echo "  !! Expected exactly 1 commit, found $COMMIT_COUNT"
    FOUND=1
  fi
  if [ "$FOUND" -eq 0 ]; then
    echo "  OK — single anonymous commit, no leftover identity strings found."
  fi
else
  # --- Step 1: rewrite author/committer identity on every commit ---
  git filter-repo --force \
    --name-callback "return b'$NEW_NAME'" \
    --email-callback "return b'$NEW_EMAIL'"

  # --- Step 2: optional text redaction of commit messages + file contents ---
  if [ -n "$REDACT_FILE" ]; then
    echo "== Redacting strings listed in: $REDACT_FILE =="

    REPLACE_FILE="$(mktemp)"
    # git-filter-repo --replace-text format: literal:OLD==>NEW  (one per line)
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      printf 'literal:%s==>[REDACTED]\n' "$line" >> "$REPLACE_FILE"
    done < "$REDACT_FILE"

    # --replace-text scrubs tracked file contents; --replace-message scrubs
    # commit messages. Both are needed.
    git filter-repo --force --replace-text "$REPLACE_FILE" --replace-message "$REPLACE_FILE"
    rm -f "$REPLACE_FILE"
  fi

  # --- Step 3: verification pass ---
  echo "== Verifying: scanning rewritten history for leftover identity strings =="
  FOUND=0
  if [ -n "$REDACT_FILE" ]; then
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      if git log --all -p | grep -qF -- "$line"; then
        echo "  !! Still found in history: $line"
        FOUND=1
      fi
    done < "$REDACT_FILE"
  fi

  if git log --all --format='%an|%ae|%cn|%ce' | grep -vF "$NEW_NAME|$NEW_EMAIL|$NEW_NAME|$NEW_EMAIL" | grep -q .; then
    echo "  !! Some commits still have a different author/committer identity:"
    git log --all --format='%an|%ae|%cn|%ce' | grep -vF "$NEW_NAME|$NEW_EMAIL|$NEW_NAME|$NEW_EMAIL" | sort -u
    FOUND=1
  fi

  if [ "$FOUND" -eq 0 ]; then
    echo "  OK — no leftover identity strings or author/committer mismatches found."
  fi
fi

# --- Step 4: local anonymous git identity for future commits ---
git config user.name "$NEW_NAME"
git config user.email "$NEW_EMAIL"

# --- Step 5: strip origin remote so you don't accidentally push over it ---
if [ "$STRIP_REMOTE" -eq 1 ]; then
  if git remote get-url origin >/dev/null 2>&1; then
    git remote remove origin
    echo "== Removed 'origin' remote. Add a new one when you're ready:"
    echo "     git remote add origin <new-url>"
  fi
fi

echo
echo "== Done =="
if [ "$DRY_RUN" -eq 1 ]; then
  echo "This was a dry run against a copy at: $WORK_REPO"
  echo "Nothing in '$REPO' was modified. Re-run without --dry-run to apply for real."
else
  echo "History rewritten in place at: $REPO"
  echo "Next steps:"
  echo "  1. Inspect: git log --all -p | less"
  echo "  2. Add a remote and force-push when ready:"
  echo "       git remote add origin <new-url>"
  echo "       git push --force --all && git push --force --tags"
  echo "  3. Read the 'WHAT THIS SCRIPT CANNOT FIX' section at the top of this script."
fi
