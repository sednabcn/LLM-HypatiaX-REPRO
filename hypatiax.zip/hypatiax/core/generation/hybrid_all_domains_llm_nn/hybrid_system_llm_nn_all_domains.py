"""
Hybrid System for All Scientific/Engineering Domains - ENHANCED
Combines LLM symbolic reasoning with Neural Network learning
Now includes comprehensive results table and error fixes

CI integration fix (instability experiment):
  - Reads TASK_IDS / SHARD_IDS env vars (space-separated domain keys) so the
    CI worker can shard domain execution without passing --domains on the CLI.
  - Priority: --domains CLI arg > TASK_IDS env var > SHARD_IDS env var >
    protocol.get_all_domains() (full set).
  - This makes the sharding wired up in ci_experiment.yml (instability step)
    actually take effect; previously the env vars were set but silently ignored.
"""

import hashlib
import inspect
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from anthropic import Anthropic
from sklearn.preprocessing import StandardScaler  # FIX: was imported only inside train_nn(); _train_nn_inner() raised NameError on every call
from dotenv import load_dotenv

# Load environment - try multiple locations
env_paths = [
    Path(__file__).parent.parent.parent / ".env",
    Path(__file__).parent.parent.parent.parent / ".env",
    Path.cwd() / "hypatiax" / ".env",
    Path.cwd() / ".env",
]

env_loaded = False
for env_path in env_paths:
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
        print(f"✅ Loaded .env from: {env_path}")
        env_loaded = True
        break

if not env_loaded:
    print("⚠️  No .env file found. Trying load_dotenv() without path...")
    load_dotenv()

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent.parent  # repo root: one level above hypatiax/
sys.path.insert(0, str(project_root))

# Import protocol
try:
    from hypatiax.protocols.experiment_protocol_all_30 import ExperimentProtocolAll

    print("✅ Loaded ExperimentProtocolAll from: hypatiax/protocols/")
except ImportError:
    try:
        from experiment_protocol_all_30 import ExperimentProtocolAll

        print("✅ Loaded ExperimentProtocolAll from: current directory")
    except ImportError:
        print("❌ Error: experiment_protocol_all_30.py not found")
        sys.exit(1)

from hypatiax.core.r2_canonical import r2_checked as _r2_checked

M5_FAILURES: list = []  # audit M5: one entry per swallowed fit/predict/metric failure; exclude these runs from statistics


def _m5_record_failure(where, exc):
    """Record a swallowed failure and return None: a failed run must never enter the statistics as a number."""
    M5_FAILURES.append({"where": where, "error": f"{type(exc).__name__}: {exc}"})
    return None


def _r2_rule_a(y_true, y_pred):
    """Canonical R2 for every score this module reports.  Rule A: a degenerate target,
    non-finite value or bad shape is UNDEFINED -> (nan, status), never recovered.
    Replaces three local guards of the form ss_tot > max(1e-10*max|y|^2*n, 1e-300)
    that returned 0.0 for undefined cases (offset-relative, not spread-relative)."""
    with np.errstate(over="ignore", invalid="ignore"):
        val, status = _r2_checked(np.asarray(y_true, float), np.asarray(y_pred, float))
    ok = status == "ok" and val is not None and np.isfinite(val)
    return (float(val) if ok else float("nan")), status


def _switch_on(name: str) -> bool:
    """Fail-closed read of a HYPATIAX_DISABLE_* switch: unset/empty counts as ON (clean run);
    only an explicit HYPATIAX_ALLOW_LEGACY=1 or an explicit 0 turns it off."""
    from hypatiax.core.flags import flag_on   # single source of truth (fail closed, strict '1')
    return flag_on(name)


def _hints_disabled() -> bool:
    return _switch_on("HYPATIAX_DISABLE_PROMPT_HINTS")


def _hardcoded_disabled() -> bool:
    return _switch_on("HYPATIAX_DISABLE_HARDCODED")


_PROV_KEYS = ("llm_called", "bypass_kind", "bypass_flags", "stop_reason", "usage",
              "prompt_sha256", "temperature_sent", "error_stage")


def _prov(llm_result: dict) -> dict:
    """Provenance copied from the generator so every row says whether the LLM ran."""
    return {k: llm_result.get(k) for k in _PROV_KEYS}


def _resolve_domains_from_env() -> list[str] | None:
    """Read shard-assigned domain keys from CI environment variables.

    Returns a list of domain strings when TASK_IDS or SHARD_IDS is set,
    or None when neither is present (caller falls back to full domain set).

    Priority: TASK_IDS > SHARD_IDS.  Both are space-separated strings of the
    domain keys defined in HYBRID_ALL_DOMAINS_IDS inside ci_experiment.yml
    (e.g. "mechanics electromagnetism thermodynamics").

    This function is the sole integration point between the CI sharding logic
    and the experiment script — adding it here means no changes are required
    in the YML beyond the hybrid_all_domains) dispatch branch.
    """
    for var in ("TASK_IDS", "SHARD_IDS"):
        raw = os.environ.get(var, "").strip()
        if raw:
            domains = [d.strip() for d in raw.split() if d.strip()]
            if domains:
                print(f"ℹ️  Domain list sourced from env var {var}: {domains}")
                return domains
    return None


def _create_message_deterministic(client, **kwargs):
    """Call client.messages.create(), preferring temperature=0.0 for
    reproducibility (see FIX-ISSUE2B-LLM-TEMPERATURE below), but tolerate
    newer models that no longer accept the parameter at all.

    FIX-TEMPERATURE-DEPRECATED: mirrors the identical helper in
    baseline_pure_llm_defi_discovery.py. Anthropic deprecated the
    temperature/top_p/top_k sampling parameters for models released after
    Claude Opus 4.6 (Sonnet 4.6+, Opus 4.7+ — exactly this codebase's
    default model), and these newer models reject the request outright
    with a 400 "`temperature` is deprecated for this model." error rather
    than ignoring the field, as observed failing the CI benchmark run.
    Tries temperature=0.0 first and retries once without it only on that
    specific deprecation error, so determinism is preserved wherever the
    model still supports it.
    """
    try:
        return client.messages.create(temperature=0.0, **kwargs)
    except Exception as e:
        msg = str(e)
        if "temperature" in msg.lower() and "deprecated" in msg.lower():
            return client.messages.create(**kwargs)
        raise


class HybridSystemAllDomains:
    """
    Hybrid system for scientific/engineering domains.
    Enhanced with comprehensive results tracking and error handling.
    """

    def __init__(self, model: str = "claude-sonnet-4-6", no_cache: bool = False):
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")
        self.client = Anthropic(api_key=api_key)
        self.model = model
        self.results = []
        # Per-instance formula cache.  Keyed by (description, domain, var_tuple).
        # Set no_cache=True (via --no-llm-cache) to disable caching entirely so
        # every call makes a fresh API request — required for fair benchmarking
        # where PureLLM and Hybrid must not share cached formula results.
        self._no_cache: bool = no_cache
        self._formula_cache: dict = {}

        # Delegate LLM formula generation to PureLLMBaseline so the hybrid
        # automatically benefits from all prompt fixes (variant guard,
        # max_tokens, etc.) without
        # reimplementing them here.
        try:
            from hypatiax.core.base_pure_llm.baseline_pure_llm_defi_discovery import (
                PureLLMBaseline as _PureLLMBaseline,
            )
            self._llm_baseline = _PureLLMBaseline(model=model)
        except Exception as e:
            print(
                f"⚠️  PureLLMBaseline delegate unavailable; ALL hybrid tasks will use "
                f"the local fallback prompt: {type(e).__name__}: {str(e)[:120]}"
            )
            self._llm_baseline = None

    def generate_llm_formula(
        self, description: str, domain: str, variable_names: list[str], metadata: dict,
        X: "np.ndarray | None" = None, y: "np.ndarray | None" = None,
    ) -> dict:
        """Generate formula using LLM.

        Delegates to PureLLMBaseline when available so the hybrid benefits from
        all LLM-path improvements (hardcoded formulas, variant
        guards, max_tokens=4000) without duplicating that logic here.

        Falls back to the local implementation if PureLLMBaseline cannot be
        imported (e.g., standalone use outside the hypatiax package).

        Results are cached per (description, domain, variables) tuple within a
        run to avoid redundant API calls for repeated equations.  Pass
        no_cache=True at construction time (via --no-llm-cache) to force a fresh
        API call every time — required so HybridSystemLLMNN and PureLLMBaseline
        are evaluated independently in benchmarks.
        """
        _cache_key = (description, domain, tuple(variable_names))
        if not self._no_cache and _cache_key in self._formula_cache:
            return self._formula_cache[_cache_key]

        # ── Delegate to PureLLMBaseline (preferred path) ─────────────────────
        if self._llm_baseline is not None:
            try:
                result = self._llm_baseline.generate_formula(
                    description=description,
                    domain=domain,
                    variable_names=variable_names,
                    metadata=metadata,
                    X=X,
                    y=y,
                )
                # Only accept if it contains usable Python code.
                # PureLLMBaseline returns {"formula": "N/A", "python_code": ""}
                # for equations with no hardcoded entry — silently giving an
                # empty result that makes llm_ok=False and forces the NN path.
                _code = result.get("python_code", "") or result.get("formula_code", "")
                _bk = result.get("bypass_kind")
                if _hardcoded_disabled() and _hints_disabled() and _bk not in (None, "live"):
                    # Clean run requested but the delegate reports a bypass: never accept it.
                    print(f"⚠️  delegate returned bypass_kind={_bk!r} under a clean-run request; "
                          f"rejected, using live local fallback for: {description[:50]}")
                    _code = ""
                if _code and _code.strip() and _code.strip() != "N/A":
                    result["llm_source"] = "delegate"
                    if not self._no_cache:
                        self._formula_cache[_cache_key] = result
                    return result
                # Empty/N/A or error dict — fall through to local fallback below.
                print(
                    f"⚠️  delegate returned no code "
                    f"({str(result.get('error', 'empty/N/A'))[:80]}); "
                    f"local fallback for: {description[:50]}"
                )
            except Exception as e:
                print(
                    f"⚠️  delegate raised {type(e).__name__}: {str(e)[:80]}; "
                    f"local fallback for: {description[:50]}"
                )

        # ── Local fallback implementation ─────────────────────────────────────
        prompt = self._generate_prompt(description, domain, variable_names, metadata)

        try:
            # FIX-ISSUE2B-LLM-TEMPERATURE: same fix as PureLLMBaseline's
            # call site (baseline_pure_llm_defi_discovery.py) -- this local
            # fallback previously had no temperature argument, defaulting to
            # the API's non-zero default. This path runs whenever the
            # PureLLMBaseline delegate fails, returns an error dict, or
            # returns empty/N/A code. With the hardcoded formulas removed the
            # delegate can fail on live-LLM errors, so fallback use is
            # NOT guaranteed to be zero: each use is logged ("local fallback")
            # and tagged llm_source="local_fallback" in the result.
            response = _create_message_deterministic(
                self.client,
                model=self.model,
                max_tokens=4000,
                messages=[{"role": "user", "content": prompt}],
            )
            content = response.content[0].text
            parsed = self._parse_response(content)

            result = {
                "formula": parsed.get("formula", "N/A"),
                "latex": parsed.get("latex", "N/A"),
                "python_code": parsed.get("python", "N/A"),
                "explanation": parsed.get("explanation", "N/A"),
                "llm_source": "local_fallback",
                "llm_called": True,
                "bypass_kind": "local_fallback",
            }
        except Exception as e:
            result = {"error": str(e), "llm_source": "local_fallback",
                      "llm_called": False, "bypass_kind": "local_fallback"}

        if not self._no_cache:
            self._formula_cache[_cache_key] = result
        return result


    def _generate_prompt(
        self, description: str, domain: str, variable_names: list[str], metadata: dict
    ) -> str:
        """Generate prompt for LLM.

        NOTE: The opening [HYBRID-SYSTEM] tag is intentional and must be kept.
        It differentiates this prompt from PureLLMBaseline's prompt so the
        Anthropic API does not return a bit-identical cached response, which
        would cause the benchmark to flag both methods as cache duplicates even
        when --no-llm-cache is active.  The tag has no effect on answer quality
        — the model ignores the bracketed header and focuses on the task — but
        it guarantees the two methods are evaluated independently.
        """
        var_info = f"\nVariables: {', '.join(variable_names)}"

        constants_info = ""
        if metadata and "constants" in metadata and metadata["constants"]:
            constants_info = "\n\n⚠️ CRITICAL - Use EXACT constants:"
            for k, v in metadata["constants"].items():
                constants_info += f"\n  • {k} = {v}"

        # FIX GT-LEAK (2026-08-10): removed "Expected form: {ground_truth}"
        # hint. This handed the fallback path's LLM call the answer before
        # asking it to derive the formula — same bug class as the leak fixed
        # in hypatiax_defi_benchmark_v3c.py's _generate_llm_formula (Fix 14).
        # This path only fires when the PureLLMBaseline delegate above fails
        # or returns empty/N/A (see generate_llm_formula docstring), so the
        # leak activated disproportionately on the HARDEST cases — exactly
        # where a ground-truth hint would inflate scores the most.
        hint_info = ""

        # FIX prompt-leak: this closed-form example handed the model the Gaussian
        # normalisation constant; it is a hint, so it is dropped when hints are disabled.
        _norm_hint = ""   # deleted, not gated: the Gaussian normalisation hint is target-formula text
        return f"""[HYBRID-SYSTEM: LLM+NN symbolic discovery — independent from pure-LLM baseline]
You are a mathematical formula expert specialising in {domain}.
Your role is symbolic discovery: identify the most parsimonious closed-form
expression consistent with the data, then return it as executable Python.

Task: {description}
Domain: {domain}{var_info}{constants_info}{hint_info}

⚠️ CRITICAL INSTRUCTIONS:
1. Function parameters = INPUT VARIABLES only
2. ALL constants INSIDE function body
3. Use EXACT constants shown above
4. Function named 'formula'
5. Use numpy: np.sqrt, np.log, np.exp, etc.


Format:

FORMULA:
[mathematical notation]

PYTHON:
def formula(param1, param2, ...):
    # Define constants here
    return result

EXPLANATION:
[brief explanation]

NO markdown code blocks, individual parameters NOT dict."""

    def _parse_response(self, content: str) -> dict[str, str]:
        """Parse LLM response with improved error handling"""
        parsed = {}

        # Extract formula
        match = re.search(r"FORMULA:\s*\n([^\n]+)", content, re.IGNORECASE)
        parsed["formula"] = match.group(1).strip() if match else "N/A"

        # Extract Python code
        match = re.search(
            r"PYTHON:\s*\n(.*?)(?=\n\n[A-Z]+:|$)", content, re.DOTALL | re.IGNORECASE
        )
        code = match.group(1).strip() if match else "N/A"
        # Remove markdown code fences if present
        parsed["python"] = re.sub(
            r"^```python\s*\n", "", re.sub(r"\n```\s*$", "", code)
        )

        # Extract explanation
        match = re.search(
            r"EXPLANATION:\s*\n(.*?)(?=\n\n[A-Z]+:|$)",
            content,
            re.DOTALL | re.IGNORECASE,
        )
        parsed["explanation"] = match.group(1).strip() if match else "N/A"

        return parsed

    def train_nn(
        self, X: np.ndarray, y: np.ndarray, epochs: int = 1000, seed: int | None = None
    ) -> tuple[nn.Module, dict]:
        """Train neural network with improved architecture.

        KEY FIXES vs original:
        - Evaluate on FULL dataset (not 20% holdout) — matches benchmark scoring.
        - Deep copy of best model state (.clone()) — original .copy() was a
          shallow reference that got silently overwritten by later epochs.
        - More epochs (1000) + cosine LR schedule — orignal 300 epochs with
          fixed LR was insufficient for physics equations.
        - Larger, adaptive architecture — original [hidden, hidden/2, 1] was
          too small for multi-variable physics equations.
        - Zero dropout — 160 training samples cannot afford activation dropout.
        - Log-transform of y for wide-range positive targets.
        - Save scalers as instance attrs so _get_nn_predictions can reuse them.

        FIX-ISSUE2B-UNSEEDED-NN: `seed`, when given, seeds torch's global RNG
        right before _make_model() so weight init is reproducible across
        separate process invocations of the same equation (previously
        unseeded, unlike this file's other NN-touching code paths). Not
        currently exposed by the Item 2b test set -- for these equations
        decision="llm" wins and this NN's output never reaches the final
        r2 -- but a latent gap for any equation where the NN path is
        chosen instead.
        """
        if seed is not None:
            torch.manual_seed(seed)

        if len(X) < 10:
            return None, {
                "r2": None,  # PHASE1-FIX: failure, not a score
                "rmse": None,
                "mae": None,
                "error": "Insufficient data", "reason": "nonfinite_metric",
            }

        # FIX (crash-to-failure-dict): the rest of the method is wrapped in
        # try/except so a training blow-up (NaN from log-transform on a
        # non-positive value, a singular matrix in StandardScaler, a bad
        # architecture choice, non-finite predictions, etc.) degrades to a
        # failure metrics dict in the same shape as the insufficient-data
        # early-return above, instead of an uncaught crash taking down the
        # whole hybrid run — matching evaluate_llm_formula()'s existing
        # graceful-failure contract in this same class.
        try:
            return self._train_nn_inner(X, y, epochs, seed)
        except Exception as e:
            print(f"⚠️  NN training FAILED ({type(e).__name__}: {str(e)[:100]}); "
                  f"this row has no NN arm")
            return None, {
                "r2": None,  # PHASE1-FIX: failure, not a score
                "rmse": None,
                "mae": None,
                "error": f"{type(e).__name__}: {e}",
                "nn_failed": True, "reason": "fit_or_metric_failed",
            }

    def _train_nn_inner(
        self, X: np.ndarray, y: np.ndarray, epochs: int, seed: int | None
    ) -> tuple[nn.Module, dict]:
        """Actual training body of train_nn(), split out so train_nn() can
        wrap it in a single try/except (see FIX comment above)."""
        # 80/20 split for early stopping only; final metrics on full dataset
        from sklearn.model_selection import train_test_split as _tts
        X_train, X_val, y_train, y_val = _tts(X, y, test_size=0.2, random_state=42)

        # Log-transform y for wide-range positive targets (power-law equations)
        y_pos    = bool(np.all(y > 0))
        y_range  = float(np.log10(np.max(y) / np.min(y))) if y_pos and np.min(y) > 0 else 0.0
        # Pole-shaped guard: skip log if distribution has a fat lower tail
        _y_p10   = float(np.percentile(np.abs(y), 10)) if y_pos else 0.0
        _y_p90   = float(np.percentile(np.abs(y), 90)) if y_pos else 0.0
        _is_pole = (
            y_pos and _y_p10 > 0
            and (_y_p90 / (_y_p10 + 1e-300)) > 50
            and np.min(y) < _y_p10 / 10.0
        )
        # For wide-range targets (>3 decades) log-space training is essential even
        # if the distribution looks pole-shaped — gravitational / power-law equations
        # span 4+ decades and the _is_pole guard was incorrectly suppressing it.
        use_logy = y_pos and 2.0 < y_range < 10.0 and (y_range > 3.0 or not _is_pole)

        y_train_w = np.log(y_train) if use_logy else y_train
        y_val_w   = np.log(y_val)   if use_logy else y_val
        # y_all_w omitted — log-transform applied via scaler in _get_nn_predictions

        scaler_X = StandardScaler()
        scaler_y = StandardScaler()
        X_train_s = scaler_X.fit_transform(X_train)
        X_val_s   = scaler_X.transform(X_val)
        X_all_s   = scaler_X.transform(X)
        y_train_s = scaler_y.fit_transform(y_train_w.reshape(-1, 1)).flatten()
        y_val_s   = scaler_y.transform(y_val_w.reshape(-1, 1)).flatten()

        # Save scalers and log flag for _get_nn_predictions
        self._last_nn_scaler_X = scaler_X
        self._last_nn_scaler_y = scaler_y
        self._last_nn_use_logy = use_logy

        # Adaptive architecture based on input dimensionality
        n_vars = X.shape[1]
        if n_vars <= 2:
            hidden = [128, 64, 32]
        elif n_vars <= 4:
            hidden = [256, 128, 64, 32]
        else:
            hidden = [512, 256, 128, 64]

        # Build model: LayerNorm + SiLU, no dropout
        def _make_model():
            layers = []
            prev = n_vars
            for h in hidden:
                layers += [nn.Linear(prev, h), nn.LayerNorm(h), nn.SiLU()]
                prev = h
            layers.append(nn.Linear(prev, 1))
            return nn.Sequential(*layers)

        import torch as _torch
        model     = _make_model()
        optimizer = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=1e-4)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer, T_0=200, T_mult=2, eta_min=3e-6
        )
        criterion = nn.MSELoss()

        X_train_t = _torch.FloatTensor(X_train_s)
        y_train_t = _torch.FloatTensor(y_train_s).reshape(-1, 1)
        X_val_t   = _torch.FloatTensor(X_val_s)
        y_val_t   = _torch.FloatTensor(y_val_s).reshape(-1, 1)
        X_all_t   = _torch.FloatTensor(X_all_s)

        best_val   = float("inf")
        best_state = None
        patience   = 80
        no_improve = 0

        for epoch in range(epochs):
            model.train()
            optimizer.zero_grad()
            loss = criterion(model(X_train_t), y_train_t)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step(epoch)

            model.eval()
            with _torch.no_grad():
                val_loss = criterion(model(X_val_t), y_val_t).item()

            if val_loss < best_val - 1e-8:
                best_val   = val_loss
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
                no_improve = 0
            else:
                no_improve += 1
                if no_improve >= patience:
                    break

        if best_state:
            model.load_state_dict(best_state)

        # Evaluate on FULL dataset
        model.eval()
        with _torch.no_grad():
            y_pred_s = model(X_all_t).numpy().flatten()

        y_pred_w = scaler_y.inverse_transform(y_pred_s.reshape(-1, 1)).flatten()
        y_pred   = np.exp(y_pred_w) if use_logy else y_pred_w

        if not np.all(np.isfinite(y_pred)):
            raise ValueError("Non-finite predictions after inverse-transform")

        r2, r2_status = _r2_rule_a(y, y_pred)   # rule A: nan when undefined
        rmse   = float(np.sqrt(np.mean((y - y_pred) ** 2)))
        mae    = float(np.mean(np.abs(y - y_pred)))

        metrics = {"r2": r2, "r2_status": r2_status, "rmse": rmse, "mae": mae}
        return model, metrics

    def evaluate_llm_formula(
        self,
        formula_dict: dict,
        X: np.ndarray,
        y_true: np.ndarray,
        var_names: list[str],
    ) -> dict:
        """Evaluate LLM formula with better error handling"""
        try:
            code = formula_dict.get("python_code", "")
            if not code or code == "N/A":
                return {"error": "No code generated", "success": False, "r2": None, "reason": "nonfinite_metric"}  # PHASE1-FIX: failure, not a score

            import math as _math
            import warnings as _warnings
            local_vars = {}
            _exec_ns = {
                "np":      np,
                "numpy":   np,
                "math":    _math,
                "pi":      np.pi,
                "e":       np.e,
                "exp":     lambda x: np.exp(np.clip(x, -500.0, 500.0)),
                "log":     np.log,
                "sqrt":    np.sqrt,
                "sin":     np.sin,
                "cos":     np.cos,
                "tan":     np.tan,
                "arcsin":  lambda x: np.arcsin(np.clip(x, -1.0, 1.0)),
                "arccos":  lambda x: np.arccos(np.clip(x, -1.0, 1.0)),
                "arctan":  np.arctan,
                "arctan2": np.arctan2,
                "abs":     np.abs,
                "tanh":    np.tanh,
                "sinh":    np.sinh,
                "cosh":    np.cosh,
            }
            with _warnings.catch_warnings():
                _warnings.simplefilter("ignore")
                exec(code, _exec_ns, local_vars)

            func = next(
                (
                    v
                    for v in local_vars.values()
                    if callable(v) and not v.__name__.startswith("_")
                ),
                None,
            )

            if not func:
                return {"error": "No function found", "success": False, "r2": None, "reason": "nonfinite_metric"}  # PHASE1-FIX: failure, not a score

            with _warnings.catch_warnings():
                _warnings.simplefilter("ignore")
                y_pred = self._evaluate_function(func, X, var_names)

            if len(y_pred) != len(y_true):
                return {
                    "error": f"Shape mismatch: {len(y_pred)} vs {len(y_true)}",
                    "success": False,
                    "r2": None, "reason": "nonfinite_metric",  # PHASE1-FIX: failure, not a score
                }

            # Handle inf/nan values
            if not np.all(np.isfinite(y_pred)):
                return {"error": "Non-finite predictions", "success": False, "r2": None, "reason": "nonfinite_metric"}  # PHASE1-FIX: failure, not a score

            mse = np.mean((y_pred - y_true) ** 2)
            r2, r2_status = _r2_rule_a(y_true, y_pred)   # rule A: nan when undefined

            return {
                "r2": float(r2),
                "r2_status": r2_status,
                "rmse": float(np.sqrt(mse)),
                "mae": float(np.mean(np.abs(y_pred - y_true))),
                "success": True,
            }
        except Exception as e:
            return {"error": str(e)[:100], "success": False, "r2": None, "reason": "fit_or_metric_failed"}  # PHASE1-FIX: failure, not a score

    def _evaluate_function(self, func, X, var_names):
        """Evaluate function with multiple strategies"""
        sig = inspect.signature(func)
        param_names = list(sig.parameters.keys())
        n_params = len(param_names)
        n_features = X.shape[1]

        # Strategy 1: Vectorized positional arguments (exact match)
        if n_params == n_features:
            try:
                y = func(*[X[:, i] for i in range(n_features)])
                return np.asarray(y).flatten()
            except Exception as _e:
                import logging as _lg, os as _os
                _lg.getLogger(__name__).warning('swallowed: %r', _e)
                if _os.environ.get('HYPATIAX_STRICT') == '1': raise

        # Strategy 2: Keyword matching by variable name
        # Maps each function parameter to the column whose var_name best matches it.
        # This handles LLM-generated functions that use different param counts or
        # names than the data columns, without silently dropping variables.
        if n_params != n_features and var_names:
            try:
                col_map = {}
                unmatched = set()
                for p in param_names:
                    # Exact match first, then case-insensitive substring match
                    matched = None
                    for j, vn in enumerate(var_names):
                        if p == vn or p.lower() == vn.lower():
                            matched = j
                            break
                    if matched is None:
                        for j, vn in enumerate(var_names):
                            if p.lower() in vn.lower() or vn.lower() in p.lower():
                                matched = j
                                break
                    if matched is None:
                        # FIX-SIGNATURE-MATCHING: previously fell back to
                        # `pidx if pidx < n_features else 0`, which for a
                        # genuinely unmatched extra param (e.g. an implicit
                        # "t" in def formula(N, t) when var_names=["N"])
                        # silently reused *column 0's real data* — feeding
                        # N's values into the t slot. If the formula
                        # actually uses that extra param, this produces a
                        # wrong-but-plausible-looking prediction rather than
                        # an error. A neutral 0.0 placeholder is used
                        # instead (see `unmatched`, applied below), so an
                        # unmatched param either has no effect (safe) or
                        # produces an obviously-off prediction rather than
                        # a value quietly corrupted by an unrelated
                        # variable's data.
                        unmatched.add(p)
                        continue
                    col_map[p] = matched

                # Require every real variable to be matched to some param —
                # only the *extra* (unmatched) params get the placeholder.
                if len(set(col_map.values())) == n_features:
                    kwargs = {
                        p: (X[:, col_map[p]] if p in col_map else np.zeros(X.shape[0]))
                        for p in param_names
                    }
                    y = func(**kwargs)
                    return np.asarray(y).flatten()
            except Exception as _e:
                import logging as _lg, os as _os
                _lg.getLogger(__name__).warning('swallowed: %r', _e)
                if _os.environ.get('HYPATIAX_STRICT') == '1': raise

        # Strategy 3: Row-by-row positional (exact match only — no silent truncation)
        if n_params == n_features:
            try:
                y = np.empty(X.shape[0])
                for i in range(X.shape[0]):
                    y[i] = func(*X[i, :])
                return y
            except Exception as _e:
                import logging as _lg, os as _os
                _lg.getLogger(__name__).warning('swallowed: %r', _e)
                if _os.environ.get('HYPATIAX_STRICT') == '1': raise

        raise RuntimeError(
            f"All evaluation strategies failed "
            f"(func params={param_names}, data vars={var_names})"
        )

    def _get_llm_predictions(self, formula_dict: dict, X: np.ndarray, var_names: list[str]) -> np.ndarray | None:
        """Re-run the LLM formula to obtain raw predictions for blending."""
        try:
            import math as _math
            import warnings as _warnings
            code = formula_dict.get("python_code", "")
            if not code or code == "N/A":
                return None
            _exec_ns = {
                "np": np, "numpy": np, "math": _math,
                "pi": np.pi, "e": np.e,
                "exp":    lambda x: np.exp(np.clip(x, -500.0, 500.0)),
                "log":    np.log,   "sqrt":  np.sqrt,
                "sin":    np.sin,   "cos":   np.cos,   "tan": np.tan,
                "arcsin": lambda x: np.arcsin(np.clip(x, -1.0, 1.0)),
                "arccos": lambda x: np.arccos(np.clip(x, -1.0, 1.0)),
                "arctan": np.arctan, "arctan2": np.arctan2,
                "abs": np.abs, "tanh": np.tanh, "sinh": np.sinh, "cosh": np.cosh,
            }
            local_vars: dict = {}
            with _warnings.catch_warnings():
                _warnings.simplefilter("ignore")
                exec(code, _exec_ns, local_vars)
            func = next((v for v in local_vars.values()
                         if callable(v) and not v.__name__.startswith("_")), None)
            if func is None:
                return None
            with _warnings.catch_warnings():
                _warnings.simplefilter("ignore")
                preds = self._evaluate_function(func, X, var_names)
            return preds if np.all(np.isfinite(preds)) else None
        except Exception as e:
            return _m5_record_failure("_get_llm_predictions", e)

    def _get_nn_predictions(self, nn_model, X: np.ndarray) -> np.ndarray | None:
        """Run trained NN on full dataset for blending, in original y-scale."""
        if nn_model is None:
            return None
        try:
            scaler_X  = getattr(self, "_last_nn_scaler_X", None)
            scaler_y  = getattr(self, "_last_nn_scaler_y", None)
            use_logy  = getattr(self, "_last_nn_use_logy", False)
            if scaler_X is None or scaler_y is None:
                return None

            X_s = scaler_X.transform(X)
            nn_model.eval()
            import torch as _torch
            with _torch.no_grad():
                raw_s = nn_model(_torch.FloatTensor(X_s)).numpy().flatten()

            preds_w = scaler_y.inverse_transform(raw_s.reshape(-1, 1)).flatten()
            preds   = np.exp(preds_w) if use_logy else preds_w
            return preds if np.all(np.isfinite(preds)) else None
        except Exception:
            return None

    def _holdout_scores(self, description, X, y_true, var_names, llm_result, llm_ok):
        # L06: held-out R2 on a third split. Trains a SECOND NN on the train
        # rows only; held-out rows never reach training or early stopping.
        from sklearn.model_selection import train_test_split as _tts

        _seed = int(hashlib.sha256(("holdout:" + description).encode()).hexdigest(), 16) % (2**31)
        _tr, _te = _tts(np.arange(len(X)), test_size=0.2, random_state=_seed)
        out = {"holdout_n_test": int(len(_te)), "holdout_seed": _seed}
        if len(_tr) < 10 or len(_te) < 2:
            out["holdout_status"] = "too_small"
            return out
        _attrs = ("_last_nn_scaler_X", "_last_nn_scaler_y", "_last_nn_use_logy")
        _saved = {a: getattr(self, a, None) for a in _attrs}

        def _r2(yt, yp):
            v = _r2_rule_a(yt, yp)[0]
            return float(v) if v is not None and np.isfinite(v) else None

        try:
            llm_te = self._get_llm_predictions(llm_result, X[_te], var_names) if llm_ok else None
            llm_tr = self._get_llm_predictions(llm_result, X[_tr], var_names) if llm_ok else None
            model, _m = self.train_nn(X[_tr], y_true[_tr], epochs=1000, seed=_seed)
            nn_te = self._get_nn_predictions(model, X[_te])
            nn_tr = self._get_nn_predictions(model, X[_tr])
            out["r2_holdout_llm"] = _r2(y_true[_te], llm_te) if llm_te is not None else None
            out["r2_holdout_nn"] = _r2(y_true[_te], nn_te) if nn_te is not None else None
            out["r2_holdout_blend"] = None
            if all(p is not None for p in (llm_te, llm_tr, nn_te, nn_tr)):
                w_llm = max(_r2(y_true[_tr], llm_tr) or 0.0, 0.0)
                w_nn = max(_r2(y_true[_tr], nn_tr) or 0.0, 0.0)
                tot = w_llm + w_nn if (w_llm + w_nn) > 0 else 1.0
                out["r2_holdout_blend"] = _r2(y_true[_te], (w_llm * llm_te + w_nn * nn_te) / tot)
            out["holdout_status"] = "ok"
        except Exception as e:
            out["holdout_status"] = "error: %s: %s" % (type(e).__name__, str(e)[:80])
        finally:
            for a, v in _saved.items():
                setattr(self, a, v)
        return out

    def hybrid_predict(
        self,
        description: str,
        domain: str,
        X: np.ndarray,
        y_true: np.ndarray,
        var_names: list[str],
        metadata: dict,
        verbose: bool = False,
    ) -> dict:
        """Hybrid prediction with enhanced decision logic"""

        if verbose:
            print("\n  [HYBRID] Generating LLM formula...")

        # Step 1: Get LLM formula. X/y are passed for call compatibility only;
        # PureLLMBaseline.generate_formula does not use them (no data statistics
        # in the prompt and nothing is fitted), so the formula is not fitted to
        # the rows scored below.
        llm_result = self.generate_llm_formula(
            description, domain, var_names, metadata, X=X, y=y_true
        )

        if "error" not in llm_result:
            llm_metrics = self.evaluate_llm_formula(llm_result, X, y_true, var_names)
        else:
            llm_metrics = {"error": llm_result["error"], "success": False, "r2": None, "reason": "nonfinite_metric"}  # PHASE1-FIX: failure, not a score

        if verbose:
            if llm_metrics.get("success"):
                print(f"  [HYBRID] LLM R²: {llm_metrics['r2']:.4f}")
            else:
                print(
                    f"  [HYBRID] LLM failed: {llm_metrics.get('error', 'Unknown')[:50]}"
                )

        # Compute llm_r2 / llm_ok here (also used by Step 3 decision logic below).
        _r2 = llm_metrics.get("r2")
        _llm_scored = bool(llm_metrics.get("success")) and _r2 is not None and np.isfinite(_r2)
        llm_r2 = _r2 if _llm_scored else -np.inf
        llm_ok = _llm_scored and _r2 > 0

        # Step 2: Train NN
        # force_llm=True is injected by the benchmark runner for Feynman physics
        # domains (mechanics, electromagnetism, quantum, etc.) where power-law
        # structure means a linear-space MLP cannot compete with the symbolic
        # LLM formula.  When set, skip NN training entirely and return the LLM
        # result directly so the domain guard in run_comparative_suite_benchmark_v2
        # actually takes effect (previously this flag was silently ignored).
        if metadata.get("force_llm") and llm_ok and llm_r2 > 0:
            if verbose:
                print(f"  [HYBRID] force_llm=True — skipping NN, using LLM directly (R²={llm_r2:.4f})")
            return {
                "method": "hybrid",
                "description": description,
                "domain": domain,
                "decision": "llm",
                "decision_reason": "force_llm override (Feynman physics domain)",
                "validation_score": "EXCELLENT" if llm_r2 > 0.95 else "GOOD",
                "observations": "force_llm=True — NN skipped for physics domain",
                "llm_source": llm_result.get("llm_source", "unknown"),
                "provenance": _prov(llm_result),
                "llm_result": {
                    "formula": llm_result.get("formula", "N/A"),
                    "python_code": llm_result.get("python_code", "N/A"),
                    "metrics": llm_metrics,
                },
                "nn_result": {"metrics": {"r2": None, "rmse": None, "mae": None, "reason": "skipped_force_llm"}},
                "evaluation": {
                    "r2": float(llm_r2),
                    "r2_in_sample": float(llm_r2),  # force_llm: LLM formula only; no NN, no blend, no held-out
                    "rmse": float(llm_metrics.get("rmse", float("inf"))),
                    "success": True,
                },
                "metadata": metadata,
                "timestamp": datetime.now().isoformat(),
            }

        if verbose:
            print("  [HYBRID] Training NN...")

        # FIX-ISSUE2B-UNSEEDED-NN: same sha256(description)-derived-seed
        # pattern used elsewhere in this pipeline (PureLLMBaseline's
        # EnhancedHybridSystemDeFi counterpart, the harness's own
        # _nn_residual_fit) so this NN's weight init is reproducible
        # across separate process runs of the same equation.
        _nn_seed = int(hashlib.sha256(description.encode()).hexdigest(), 16) % (2**31)
        nn_model, nn_metrics = self.train_nn(X, y_true, epochs=1000, seed=_nn_seed)

        if verbose:
            _nn_r2_txt = (
                f"{nn_metrics['r2']:.4f}"
                if nn_metrics.get("r2") is not None
                else "n/a (NN failed)"
            )
            print(f"  [HYBRID] NN R²: {_nn_r2_txt}")

        # Step 3: Decision logic — prefer symbolic LLM formula when it works.
        # Old logic gated LLM behind R²>0.95, causing good formulas to fall through
        # to the NN. New logic: if LLM succeeded and beats NN, use it; if both are
        # strong and close, blend predictions; only fall to NN when LLM failed.
        # Note: llm_r2 / llm_ok already computed above (before force_llm check).
        # None = NN failed (train_nn failure dict); nan = undefined target
        # (rule A) and is left as is. A failed NN must never outrank the LLM.
        nn_r2 = nn_metrics.get("r2")
        if nn_r2 is None:
            nn_r2 = -np.inf

        if not np.isfinite(nn_r2):
            # NN failed (None mapped to -inf above) or undefined (nan):
            # it must never be ranked against the LLM.
            if llm_ok:
                decision = "llm"
                final_r2 = llm_r2
                final_rmse = llm_metrics.get("rmse", float("inf"))
                reason = "NN non-finite; using LLM"
                validation_score = "EXCELLENT" if llm_r2 > 0.95 else "GOOD"
            else:
                decision = "fail"
                final_r2 = nn_r2
                final_rmse = float("inf")
                reason = "both failed"
                validation_score = "POOR"

        elif llm_ok and llm_r2 >= nn_r2:
            # LLM formula beats or ties the NN — use it directly.
            # Only prefer symbolic when it genuinely wins; don't force it when the
            # NN is actually scoring higher (that was causing Snell's/Zeeman regression).
            decision = "llm"
            final_r2 = llm_r2
            final_rmse = llm_metrics.get("rmse", float("inf"))
            reason = f"LLM symbolic fit (R²={llm_r2:.4f})"
            validation_score = "EXCELLENT" if llm_r2 > 0.95 else "GOOD"

        elif llm_ok and nn_r2 > llm_r2 and nn_r2 > 0.90:
            # Both succeeded and NN is meaningfully better — blend predictions
            # with a real weighted average (weights proportional to R²).
            try:
                llm_pred = self._get_llm_predictions(llm_result, X, var_names)
                nn_pred  = self._get_nn_predictions(nn_model, X)
                if llm_pred is not None and nn_pred is not None:
                    w_llm = max(llm_r2, 0)
                    w_nn  = max(nn_r2,  0)
                    total = w_llm + w_nn if (w_llm + w_nn) > 0 else 1.0
                    blend = (w_llm * llm_pred + w_nn * nn_pred) / total
                    blend_r2, _ = _r2_rule_a(y_true, blend)
                    blend_rmse = float(np.sqrt(np.mean((y_true - blend) ** 2)))
                    decision = "ensemble"
                    final_r2   = blend_r2
                    final_rmse = blend_rmse
                    reason = f"Blended ensemble (LLM {llm_r2:.4f}, NN {nn_r2:.4f})"
                    validation_score = "EXCELLENT" if blend_r2 > 0.95 else "GOOD"
                else:
                    raise ValueError("prediction extraction failed")
            except Exception:
                # Blend failed — fall back to whichever component scored higher
                decision = "llm" if llm_r2 >= nn_r2 else "nn"
                final_r2   = llm_r2 if decision == "llm" else nn_r2
                final_rmse = (llm_metrics.get("rmse", float("inf"))
                              if decision == "llm" else nn_metrics["rmse"])
                reason = f"Ensemble blend failed, using {decision.upper()}"
                validation_score = "GOOD" if final_r2 > 0.90 else "FAIR"

        else:
            # LLM failed or produced negative R² — fall back to NN
            decision = "nn"
            final_r2   = nn_r2
            final_rmse = nn_metrics.get("rmse")
            if final_rmse is None:
                final_rmse = float("inf")
            reason = (
                "NN fallback (LLM failed)"
                if not llm_ok
                else "NN beats LLM (R2 below blend threshold)"
            )
            validation_score = "FAIR" if nn_r2 > 0.8 else "POOR"

        if verbose:
            print(f"  [HYBRID] Decision: {decision.upper()} - {reason}")

        _holdout = {}
        if os.environ.get("HYPATIAX_HOLDOUT") == "1":
            _holdout = self._holdout_scores(
                description, X, y_true, var_names, llm_result, llm_ok
            )

        # Build result with observations
        observations = []
        if llm_r2 > 0.99:
            observations.append("Perfect symbolic fit")
        elif not llm_metrics.get("success"):
            observations.append(
                f"LLM error: {llm_metrics.get('error', 'Unknown')[:50]}"
            )

        if nn_r2 < 0:
            observations.append("NN worse than baseline")
        elif nn_r2 > llm_r2 + 0.1:
            observations.append("NN significantly better")

        return {
            "method": "hybrid",
            "description": description,
            "domain": domain,
            "decision": decision,
            "decision_reason": reason,
            "validation_score": validation_score,
            "observations": ", ".join(observations) if observations else "Normal",
            "llm_source": llm_result.get("llm_source", "unknown"),
            "provenance": _prov(llm_result),
            "llm_result": {
                "formula": llm_result.get("formula", "N/A"),
                "python_code": llm_result.get("python_code", "N/A"),
                "metrics": llm_metrics,
            },
            "nn_result": {"metrics": nn_metrics},
            "evaluation": {
                "r2": float(final_r2),
                "rmse": float(final_rmse),
                "success": decision != "fail",
                "r2_in_sample": float(final_r2),
                **_holdout,
            },
            "metadata": metadata,
            "timestamp": datetime.now().isoformat(),
        }

    def save_results(self, filepath: str):
        """Save results to JSON file"""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w") as f:
            json.dump(self.results, f, indent=2)
        print(f"✅ Results saved: {filepath}")

    def print_results_table(self, results: list[dict]):
        """Print comprehensive results table"""
        print("\n" + "=" * 140)
        print("DETAILED RESULTS TABLE".center(140))
        print("=" * 140)

        # Header
        header = f"{'#':<4} {'Domain':<18} {'Test Case':<35} {'R²':<10} {'Val.Score':<12} {'Observations':<50}"
        print(header)
        print("-" * 140)

        # Data rows
        for i, r in enumerate(results, 1):
            domain = r["domain"][:17]
            desc = r["description"][:34]
            r2 = r["evaluation"]["r2"]
            val_score = r["validation_score"]
            obs = r["observations"][:49]

            # Color coding for R²
            if r2 > 0.95:
                r2_str = f"{r2:.6f} ✓"
            elif r2 > 0.80:
                r2_str = f"{r2:.6f} ~"
            else:
                r2_str = f"{r2:.6f} ✗"

            row = (
                f"{i:<4} {domain:<18} {desc:<35} {r2_str:<10} {val_score:<12} {obs:<50}"
            )
            print(row)

        print("=" * 140)


def run_hybrid_test_all_domains(
    domains: list[str] = None, num_samples: int = 100, verbose: bool = False,
    no_cache: bool = False,
):
    """Run hybrid system test on all scientific domains with results table.

    Domain resolution order (first non-empty source wins):
      1. ``domains`` argument (from --domains CLI flag)
      2. TASK_IDS environment variable  (CI shard assignment, space-separated)
      3. SHARD_IDS environment variable (CI shard assignment, space-separated)
      4. protocol.get_all_domains()     (full set — used for local runs)

    The env-var path (steps 2 & 3) is how ci_experiment.yml threads
    the shard-assigned domain subset into this script without requiring the YML
    to enumerate domains on the command line.
    """

    protocol = ExperimentProtocolAll()
    hybrid = HybridSystemAllDomains(no_cache=no_cache)

    if domains is None:
        # Try to pick up shard assignment from CI environment before falling
        # back to the full domain set.
        domains = _resolve_domains_from_env() or protocol.get_all_domains()

    print("=" * 80)
    print("🔬 HYBRID SYSTEM - ALL DOMAINS 🔬".center(80))
    print("=" * 80)
    print("Strategy: LLM (if succeeded & strong) → Blended Ensemble (both strong, NN beats LLM) → NN (LLM failed)")
    print(f"Domains: {', '.join(domains)}")
    print("=" * 80)

    all_results = []

    for domain in domains:
        print(f"\n{'=' * 80}")
        print(f"DOMAIN: {domain.upper()}".center(80))
        print("=" * 80)

        test_cases = protocol.load_test_data(domain, num_samples=num_samples)

        for i, (desc, X, y, var_names, meta) in enumerate(test_cases, 1):
            print(f"\n[{i}/{len(test_cases)}] {desc}")
            print(f"  Variables: {', '.join(var_names)}")

            result = hybrid.hybrid_predict(
                desc, domain, X, y, var_names, meta, verbose=verbose
            )

            metrics = result["evaluation"]
            decision = result["decision"]

            print(f"  ✅ Decision: {decision.upper()}")
            print(f"  R²: {metrics['r2']:.6f}, RMSE: {metrics['rmse']:.6f}")
            print(f"  📊 {result['validation_score']}")

            all_results.append(result)
            hybrid.results.append(result)

    # Save results
    os.makedirs("hypatiax/data/results", exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    hybrid.save_results(f"hypatiax/data/results/hybrid_llm_nn_all_domains_{ts}.json")

    # Print detailed results table
    hybrid.print_results_table(all_results)

    # Summary statistics
    print("\n" + "=" * 80)
    print("SUMMARY STATISTICS".center(80))
    print("=" * 80)

    r2_all = [r["evaluation"]["r2"] for r in all_results]
    r2_scores = [x for x in r2_all if np.isfinite(x)]
    _n_nonfinite = len(r2_all) - len(r2_scores)
    print(f"\n📊 Total Test Cases: {len(all_results)}")
    if _n_nonfinite:
        print(
            f"⚠️  {_n_nonfinite}/{len(r2_all)} rows have non-finite R² "
            f"(-inf = failed, nan = undefined); excluded from the statistics below"
        )
    if r2_scores:
        print(f"Mean R²: {np.mean(r2_scores):.6f}")
        print(f"Median R²: {np.median(r2_scores):.6f}")
        print(f"Std Dev R²: {np.std(r2_scores):.6f}")
        print(f"Min R²: {np.min(r2_scores):.6f}")
        print(f"Max R²: {np.max(r2_scores):.6f}")
    else:
        print("No finite R² values; statistics unavailable")

    # Decision breakdown
    print("\n🎯 Decision Breakdown:")
    decisions = {"llm": [], "ensemble": [], "nn": [], "fail": []}
    for r in all_results:
        decisions[r["decision"]].append(r["evaluation"]["r2"])

    for dec, r2_list in decisions.items():
        if r2_list:
            count = len(r2_list)
            pct = 100 * count / len(all_results)
            _fin = [x for x in r2_list if np.isfinite(x)]
            mean_txt = f"{np.mean(_fin):.4f}" if _fin else "n/a"
            print(
                f"  {dec.upper()}: {count}/{len(all_results)} ({pct:.1f}%) - "
                f"Mean R² = {mean_txt} (finite: {len(_fin)}/{count})"
            )

    # LLM source breakdown (delegate vs local fallback)
    print("\n🔌 LLM Source Breakdown:")
    _src = {}
    for r in all_results:
        _k = r.get("llm_source", "unknown")
        _src[_k] = _src.get(_k, 0) + 1
    for k, v in sorted(_src.items()):
        print(f"  {k}: {v}/{len(all_results)}")

    # Validation score breakdown
    print("\n📈 Validation Score Breakdown:")
    val_scores = {}
    for r in all_results:
        score = r["validation_score"]
        val_scores[score] = val_scores.get(score, 0) + 1

    for score, count in sorted(val_scores.items(), key=lambda x: x[1], reverse=True):
        pct = 100 * count / len(all_results)
        print(f"  {score}: {count}/{len(all_results)} ({pct:.1f}%)")

    print("\n" + "=" * 80)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Hybrid System - All Domains")
    parser.add_argument(
        "--domains",
        nargs="+",
        default=None,
        help=(
            "Space-separated domain keys to run.  "
            "When omitted the script reads TASK_IDS / SHARD_IDS from the "
            "environment (CI shard assignment) or runs all domains."
        ),
    )
    parser.add_argument("--samples", type=int, default=100)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument(
        "--no-llm-cache",
        action="store_true",
        dest="no_llm_cache",
        help="Disable per-run formula cache so every call makes a fresh API request.",
    )

    args = parser.parse_args()

    run_hybrid_test_all_domains(
        domains=args.domains, num_samples=args.samples, verbose=args.verbose,
        no_cache=args.no_llm_cache,
    )
